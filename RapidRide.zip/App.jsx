import { useState, useEffect, useCallback } from "react";

// ============================================================
// CONFIG — Your Oracle APEX ORDS base URL
// ============================================================
const BASE_URL = "https://oracleapex.com/ords/rapidride/rapidride";

// ============================================================
// API SERVICE LAYER
// ============================================================
const api = {
  async post(endpoint, body) {
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: `HTTP ${res.status}` }));
      throw new Error(err.message || err.error || `Request failed (${res.status})`);
    }
    return res.json();
  },
  async get(endpoint) {
    const res = await fetch(`${BASE_URL}${endpoint}`, {
      headers: { "Content-Type": "application/json" },
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({ message: `HTTP ${res.status}` }));
      throw new Error(err.message || err.error || `Request failed (${res.status})`);
    }
    return res.json();
  },
  login: (customer_id, phone) => api.post("/login", { customer_id, phone }),
  register: (data) => api.post("/register", data),
  getLocations: () => api.get("/locations"),
  getVehicleTypes: () => api.get("/vehicle-types"),
  bookRide: (payload) => api.post("/book", payload),
  getRides: (customer_id) => api.get(`/rides/${customer_id}`),
};

// ============================================================
// ICONS
// ============================================================
const Icon = ({ d, size = 20, color = "currentColor", className = "" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2"
    strokeLinecap="round" strokeLinejoin="round" className={className}>
    <path d={d} />
  </svg>
);
const ICONS = {
  car:     "M5 17H3a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v5a2 2 0 01-2 2h-2M7 17a2 2 0 100 4 2 2 0 000-4zm10 0a2 2 0 100 4 2 2 0 000-4z",
  map:     "M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z M12 10a1 1 0 100-2 1 1 0 000 2z",
  history: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z",
  user:    "M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2 M12 11a4 4 0 100-8 4 4 0 000 8z",
  logout:  "M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4 M16 17l5-5-5-5 M21 12H9",
  check:   "M20 6L9 17l-5-5",
  alert:   "M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z M12 9v4 M12 17h.01",
  arrow:   "M5 12h14 M12 5l7 7-7 7",
  star:    "M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z",
  phone:   "M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.8a19.79 19.79 0 01-3.07-8.68A2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z",
  edit:    "M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7 M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z",
};

// ============================================================
// STYLES
// ============================================================
const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Syne:wght@700;800&display=swap');
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  :root {
    --bg: #0B0F1A; --surface: #141923; --card: #1C2333; --border: #2A3347;
    --accent: #F5A623; --accent2: #FF6B35; --text: #E8EDF5; --muted: #7A8BA6;
    --success: #34D399; --danger: #F87171; --info: #60A5FA; --r: 14px; --r-sm: 8px;
    --shadow: 0 4px 24px rgba(0,0,0,.45);
  }
  body { background: var(--bg); color: var(--text); font-family: 'Inter', sans-serif; min-height: 100dvh; }
  .app { display: flex; flex-direction: column; min-height: 100dvh; max-width: 480px; margin: 0 auto; }
  .login-page { display: flex; flex-direction: column; justify-content: center; padding: 32px 24px; min-height: 100dvh; gap: 24px; }
  .login-hero { text-align: center; }
  .login-logo { font-family: 'Syne', sans-serif; font-size: 36px; font-weight: 800; background: linear-gradient(135deg, var(--accent), var(--accent2)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; letter-spacing: -1px; }
  .login-tagline { color: var(--muted); font-size: 14px; margin-top: 6px; }
  .login-taxi { font-size: 64px; display: block; margin-bottom: 8px; }
  .card { background: var(--card); border: 1px solid var(--border); border-radius: var(--r); padding: 24px; }
  .card-title { font-size: 18px; font-weight: 700; margin-bottom: 4px; }
  .card-sub { color: var(--muted); font-size: 13px; margin-bottom: 20px; }
  .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 14px; }
  .field label { font-size: 12px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .6px; }
  .field input, .field select { background: var(--bg); border: 1px solid var(--border); border-radius: var(--r-sm); padding: 12px 14px; color: var(--text); font-size: 15px; font-family: inherit; outline: none; transition: border-color .2s; }
  .field input:focus, .field select:focus { border-color: var(--accent); }
  .field select option { background: var(--surface); }
  .btn { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 14px 20px; border-radius: var(--r-sm); font-weight: 600; font-size: 15px; font-family: inherit; cursor: pointer; border: none; transition: opacity .15s, transform .1s; width: 100%; }
  .btn:active { transform: scale(.98); }
  .btn:disabled { opacity: .5; cursor: not-allowed; }
  .btn-primary { background: linear-gradient(135deg, var(--accent), var(--accent2)); color: #0B0F1A; }
  .btn-ghost { background: transparent; color: var(--text); border: 1px solid var(--border); }
  .btn-danger { background: rgba(248,113,113,.15); color: var(--danger); border: 1px solid rgba(248,113,113,.3); }
  .btn-link { background: transparent; color: var(--accent); border: none; font-size: 14px; cursor: pointer; font-family: inherit; font-weight: 500; padding: 8px 0; width: 100%; text-align: center; }
  .header { background: var(--surface); border-bottom: 1px solid var(--border); padding: 16px 20px; display: flex; align-items: center; justify-content: space-between; position: sticky; top: 0; z-index: 10; }
  .header-logo { font-family: 'Syne', sans-serif; font-size: 22px; font-weight: 800; background: linear-gradient(135deg, var(--accent), var(--accent2)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
  .header-welcome { font-size: 13px; color: var(--muted); }
  .bottom-nav { background: var(--surface); border-top: 1px solid var(--border); display: grid; grid-template-columns: repeat(4, 1fr); position: sticky; bottom: 0; }
  .nav-btn { display: flex; flex-direction: column; align-items: center; gap: 4px; padding: 12px 0; background: none; border: none; color: var(--muted); font-size: 11px; font-family: inherit; cursor: pointer; transition: color .15s; }
  .nav-btn.active { color: var(--accent); }
  .page { flex: 1; overflow-y: auto; padding: 20px; display: flex; flex-direction: column; gap: 16px; }
  .section-title { font-size: 13px; font-weight: 600; color: var(--muted); text-transform: uppercase; letter-spacing: .6px; margin-bottom: 4px; }
  .stat-row { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
  .stat-card { background: var(--card); border: 1px solid var(--border); border-radius: var(--r); padding: 18px; }
  .stat-val { font-family: 'Syne', sans-serif; font-size: 28px; font-weight: 800; }
  .stat-label { font-size: 12px; color: var(--muted); margin-top: 4px; }
  .accent-text { background: linear-gradient(135deg, var(--accent), var(--accent2)); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
  .quick-book { background: linear-gradient(135deg, var(--accent) 0%, var(--accent2) 100%); border-radius: var(--r); padding: 20px; cursor: pointer; border: none; width: 100%; display: flex; align-items: center; justify-content: space-between; color: #0B0F1A; font-family: inherit; }
  .quick-book-label { font-size: 13px; font-weight: 600; opacity: .75; }
  .quick-book-title { font-family: 'Syne', sans-serif; font-size: 20px; font-weight: 800; margin-top: 4px; }
  .ride-card { background: var(--card); border: 1px solid var(--border); border-radius: var(--r); padding: 16px; display: flex; flex-direction: column; gap: 10px; margin-bottom: 10px; }
  .ride-header { display: flex; justify-content: space-between; align-items: flex-start; }
  .ride-id { font-size: 12px; color: var(--muted); }
  .badge { padding: 3px 10px; border-radius: 20px; font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: .4px; }
  .badge-completed   { background: rgba(52,211,153,.15); color: var(--success); }
  .badge-requested   { background: rgba(245,166,35,.15);  color: var(--accent); }
  .badge-in_progress { background: rgba(96,165,250,.15);  color: var(--info); }
  .badge-cancelled   { background: rgba(248,113,113,.15); color: var(--danger); }
  .badge-accepted    { background: rgba(96,165,250,.15);  color: var(--info); }
  .badge-no_show     { background: rgba(122,139,166,.15); color: var(--muted); }
  .badge-active      { background: rgba(52,211,153,.15);  color: var(--success); }
  .route-line { display: flex; flex-direction: column; gap: 4px; padding-left: 12px; border-left: 2px solid var(--border); }
  .route-point { font-size: 13px; color: var(--muted); }
  .route-point span { color: var(--text); font-weight: 500; }
  .ride-meta { display: flex; gap: 16px; font-size: 12px; color: var(--muted); flex-wrap: wrap; }
  .ride-fare { font-family: 'Syne', sans-serif; font-size: 18px; font-weight: 700; }
  .fare-preview { background: var(--card); border: 1px solid var(--accent); border-radius: var(--r); padding: 16px; text-align: center; }
  .fare-big { font-family: 'Syne', sans-serif; font-size: 36px; font-weight: 800; }
  .fare-label { font-size: 12px; color: var(--muted); margin-top: 4px; }
  .vehicle-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
  .vehicle-option { background: var(--card); border: 2px solid var(--border); border-radius: var(--r-sm); padding: 12px; cursor: pointer; transition: border-color .15s; text-align: left; font-family: inherit; }
  .vehicle-option.selected { border-color: var(--accent); }
  .vehicle-name { font-weight: 600; font-size: 14px; color: var(--text); }
  .vehicle-rate { font-size: 12px; color: var(--muted); margin-top: 3px; }
  .vehicle-capacity { font-size: 11px; color: var(--muted); }
  .avatar { width: 72px; height: 72px; border-radius: 50%; background: linear-gradient(135deg, var(--accent), var(--accent2)); display: flex; align-items: center; justify-content: center; font-family: 'Syne', sans-serif; font-size: 28px; font-weight: 800; color: #0B0F1A; }
  .info-row { display: flex; align-items: center; gap: 10px; padding: 14px 0; border-bottom: 1px solid var(--border); }
  .info-row:last-child { border-bottom: none; }
  .info-label { font-size: 12px; color: var(--muted); flex: 1; }
  .info-value { font-size: 14px; font-weight: 500; }
  .toast-wrap { position: fixed; top: 16px; left: 50%; transform: translateX(-50%); z-index: 999; width: calc(100% - 32px); max-width: 440px; pointer-events: none; }
  .toast { display: flex; align-items: center; gap: 10px; padding: 14px 16px; border-radius: var(--r-sm); font-size: 14px; font-weight: 500; box-shadow: var(--shadow); pointer-events: all; animation: slideDown .25s ease; }
  .toast-success { background: rgba(52,211,153,.15); border: 1px solid var(--success); color: var(--success); }
  .toast-error   { background: rgba(248,113,113,.15); border: 1px solid var(--danger);  color: var(--danger); }
  @keyframes slideDown { from { transform: translateY(-12px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
  .empty { text-align: center; padding: 48px 24px; color: var(--muted); }
  .empty-icon { font-size: 48px; margin-bottom: 12px; }
  .loading-dot { display: inline-block; width: 8px; height: 8px; border-radius: 50%; background: var(--accent); animation: pulse 1s infinite; }
  .loading-dot:nth-child(2) { animation-delay: .2s; }
  .loading-dot:nth-child(3) { animation-delay: .4s; }
  @keyframes pulse { 0%,100% { opacity: .3; } 50% { opacity: 1; } }
  .loading-row { display: flex; gap: 6px; justify-content: center; padding: 32px; }
  .error-box { background: rgba(248,113,113,.1); border: 1px solid rgba(248,113,113,.3); border-radius: var(--r-sm); padding: 14px 16px; color: var(--danger); font-size: 14px; display: flex; align-items: flex-start; gap: 10px; }
  .divider { display: flex; align-items: center; gap: 12px; color: var(--muted); font-size: 13px; }
  .divider::before, .divider::after { content: ''; flex: 1; height: 1px; background: var(--border); }
`;

// ============================================================
// SMALL COMPONENTS
// ============================================================
const Spinner = () => (
  <div className="loading-row">
    <span className="loading-dot" /><span className="loading-dot" /><span className="loading-dot" />
  </div>
);
const ErrorBox = ({ msg }) => (
  <div className="error-box">
    <Icon d={ICONS.alert} size={18} color="currentColor" />
    <span>{msg}</span>
  </div>
);
const Toast = ({ toast }) => (
  <div className="toast-wrap">
    {toast && (
      <div className={`toast toast-${toast.type}`}>
        <Icon d={toast.type === "success" ? ICONS.check : ICONS.alert} size={18} />
        {toast.msg}
      </div>
    )}
  </div>
);
const Badge = ({ status }) => (
  <span className={`badge badge-${status?.toLowerCase()}`}>{status}</span>
);

function calcFare(vt, distance) {
  if (!vt || !distance) return null;
  return (parseFloat(vt.base_fare) + parseFloat(vt.rate_per_km) * parseFloat(distance)).toFixed(2);
}

// ============================================================
// REGISTER PAGE
// ============================================================
function RegisterPage({ onBack, onRegister }) {
  const [form, setForm]     = useState({ full_name: "", phone: "", email: "", address: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError]   = useState("");

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const submit = async () => {
    if (!form.full_name || !form.phone) { setError("Full name and phone are required."); return; }
    if (form.phone.length < 10) { setError("Phone number must be at least 10 digits."); return; }
    setLoading(true); setError("");
    try {
      const data = await api.register(form);
      if (data.error) throw new Error(data.error);
      onRegister(data);
    } catch (e) {
      setError(e.message || "Registration failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <span className="login-taxi">🚖</span>
        <div className="login-logo">RapidRide</div>
        <div className="login-tagline">Create your account</div>
      </div>
      <div className="card">
        <div className="card-title">Register</div>
        <div className="card-sub">Fill in your details to get started.</div>
        {error && <ErrorBox msg={error} />}
        <div style={{ marginTop: error ? 14 : 0 }}>
          <div className="field">
            <label>Full Name *</label>
            <input type="text" placeholder="e.g. Fatima Noor" value={form.full_name}
              onChange={e => set("full_name", e.target.value)} />
          </div>
          <div className="field">
            <label>Phone Number *</label>
            <input type="tel" placeholder="e.g. 0612345710" value={form.phone}
              onChange={e => set("phone", e.target.value)} />
          </div>
          <div className="field">
            <label>Email (optional)</label>
            <input type="email" placeholder="e.g. name@email.com" value={form.email}
              onChange={e => set("email", e.target.value)} />
          </div>
          <div className="field">
            <label>Address (optional)</label>
            <input type="text" placeholder="e.g. Mogadishu, Somalia" value={form.address}
              onChange={e => set("address", e.target.value)} />
          </div>
        </div>
        <button className="btn btn-primary" onClick={submit} disabled={loading}>
          {loading ? <Spinner /> : <><Icon d={ICONS.check} size={18} />Create Account</>}
        </button>
        <div style={{ marginTop: 12 }}>
          <div className="divider">or</div>
          <button className="btn-link" onClick={onBack}>Already have an account? Sign in</button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// LOGIN PAGE
// ============================================================
function LoginPage({ onLogin, onRegister }) {
  const [customerId, setCustomerId] = useState("");
  const [phone, setPhone]           = useState("");
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState("");

  const submit = async () => {
    if (!customerId || !phone) { setError("Please fill in both fields."); return; }
    setLoading(true); setError("");
    try {
      const data = await api.login(Number(customerId), phone);
      if (data.error) throw new Error(data.error);
      onLogin(data);
    } catch (e) {
      setError(e.message || "Login failed. Check your credentials.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-page">
      <div className="login-hero">
        <span className="login-taxi">🚖</span>
        <div className="login-logo">RapidRide</div>
        <div className="login-tagline">Your ride, on demand</div>
      </div>
      <div className="card">
        <div className="card-title">Sign in</div>
        <div className="card-sub">Use your Customer ID and registered phone number.</div>
        {error && <ErrorBox msg={error} />}
        <div style={{ marginTop: error ? 14 : 0 }}>
          <div className="field">
            <label>Customer ID</label>
            <input type="number" placeholder="e.g. 1000" value={customerId}
              onChange={e => setCustomerId(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} />
          </div>
          <div className="field">
            <label>Phone Number</label>
            <input type="tel" placeholder="e.g. 0612345699" value={phone}
              onChange={e => setPhone(e.target.value)} onKeyDown={e => e.key === "Enter" && submit()} />
          </div>
        </div>
        <button className="btn btn-primary" onClick={submit} disabled={loading}>
          {loading ? <Spinner /> : <><Icon d={ICONS.arrow} size={18} />Sign In</>}
        </button>
        <div style={{ marginTop: 12 }}>
          <div className="divider">or</div>
          <button className="btn-link" onClick={onRegister}>New customer? Create an account</button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// DASHBOARD
// ============================================================
function Dashboard({ customer, onBook, recentRides, ridesLoading }) {
  const initials = customer.full_name?.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div className="page">
      <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
        <div className="avatar">{initials}</div>
        <div>
          <div style={{ fontSize: 13, color: "var(--muted)" }}>Good day,</div>
          <div style={{ fontSize: 20, fontWeight: 700 }}>{customer.full_name}</div>
        </div>
      </div>
      <button className="quick-book" onClick={onBook}>
        <div>
          <div className="quick-book-label">Ready to go?</div>
          <div className="quick-book-title">Book a Ride</div>
        </div>
        <Icon d={ICONS.car} size={32} color="#0B0F1A" />
      </button>
      <div className="stat-row">
        <div className="stat-card">
          <div className="stat-val accent-text">{customer.total_rides ?? 0}</div>
          <div className="stat-label">Total Rides</div>
        </div>
        <div className="stat-card">
          <div className="stat-val accent-text">${Number(customer.total_spent ?? 0).toFixed(2)}</div>
          <div className="stat-label">Total Spent</div>
        </div>
      </div>
      <div>
        <div className="section-title">Recent Rides</div>
        {ridesLoading ? <Spinner /> : recentRides.length === 0 ? (
          <div className="empty"><div className="empty-icon">🚕</div><div>No rides yet.</div></div>
        ) : recentRides.slice(0, 3).map(r => <RideCard key={r.ride_id} ride={r} />)}
      </div>
    </div>
  );
}

// ============================================================
// BOOK RIDE
// ============================================================
function BookRide({ customer, onToast }) {
  const [locations, setLocations]       = useState([]);
  const [vehicleTypes, setVehicleTypes] = useState([]);
  const [loading, setLoading]           = useState(true);
  const [error, setError]               = useState("");
  const [booking, setBooking]           = useState(false);
  const [success, setSuccess]           = useState(null);
  const [pickupId, setPickupId]         = useState("");
  const [dropoffId, setDropoffId]       = useState("");
  const [vtId, setVtId]                 = useState("");
  const [distance, setDistance]         = useState("");

  const selectedVt = vehicleTypes.find(v => String(v.vehicle_type_id) === String(vtId));
  const fare = calcFare(selectedVt, distance);

  useEffect(() => {
    Promise.all([api.getLocations(), api.getVehicleTypes()])
      .then(([locData, vtData]) => {
        setLocations(locData.items ?? locData);
        setVehicleTypes(vtData.items ?? vtData);
      })
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const submit = async () => {
    if (!pickupId || !dropoffId || !vtId || !distance) { setError("Please fill in all fields."); return; }
    if (pickupId === dropoffId) { setError("Pickup and drop-off must be different."); return; }
    if (parseFloat(distance) <= 0) { setError("Distance must be greater than 0."); return; }
    setBooking(true); setError("");
    try {
      const data = await api.bookRide({
        customer_id: customer.customer_id,
        pickup_location_id: Number(pickupId),
        dropoff_location_id: Number(dropoffId),
        vehicle_type_id: Number(vtId),
        distance_km: parseFloat(distance),
      });
      setSuccess(data);
      onToast("success", `Ride #${data.ride_id} booked! Fare: $${Number(data.estimated_fare).toFixed(2)}`);
    } catch (e) {
      setError(e.message || "Booking failed. Please try again.");
    } finally {
      setBooking(false);
    }
  };

  if (loading) return <div className="page"><Spinner /></div>;

  if (success) return (
    <div className="page" style={{ justifyContent: "center", textAlign: "center", gap: 20 }}>
      <div style={{ fontSize: 72 }}>🎉</div>
      <div style={{ fontSize: 22, fontWeight: 700 }}>Ride Booked!</div>
      <div className="card" style={{ textAlign: "left" }}>
        <div className="info-row"><span className="info-label">Ride ID</span><span className="info-value">#{success.ride_id}</span></div>
        <div className="info-row"><span className="info-label">Estimated Fare</span><span className="info-value accent-text">${Number(success.estimated_fare).toFixed(2)}</span></div>
        <div className="info-row"><span className="info-label">Status</span><Badge status={success.status ?? "REQUESTED"} /></div>
      </div>
      <button className="btn btn-ghost" onClick={() => { setSuccess(null); setPickupId(""); setDropoffId(""); setVtId(""); setDistance(""); }}>
        Book Another Ride
      </button>
    </div>
  );

  return (
    <div className="page">
      <div style={{ fontSize: 20, fontWeight: 700 }}>Book a Ride</div>
      {error && <ErrorBox msg={error} />}
      <div>
        <div className="section-title">Pickup Location</div>
        <div className="field">
          <select value={pickupId} onChange={e => setPickupId(e.target.value)}>
            <option value="">Select pickup…</option>
            {locations.map(l => <option key={l.location_id} value={l.location_id}>{l.location_name} — {l.city}</option>)}
          </select>
        </div>
      </div>
      <div>
        <div className="section-title">Drop-off Location</div>
        <div className="field">
          <select value={dropoffId} onChange={e => setDropoffId(e.target.value)}>
            <option value="">Select drop-off…</option>
            {locations.map(l => <option key={l.location_id} value={l.location_id}>{l.location_name} — {l.city}</option>)}
          </select>
        </div>
      </div>
      <div>
        <div className="section-title">Distance (km)</div>
        <div className="field">
          <input type="number" placeholder="e.g. 12.5" min="0.1" step="0.1" value={distance}
            onChange={e => setDistance(e.target.value)} />
        </div>
      </div>
      <div>
        <div className="section-title" style={{ marginBottom: 10 }}>Vehicle Type</div>
        <div className="vehicle-grid">
          {vehicleTypes.map(vt => (
            <button key={vt.vehicle_type_id} className={`vehicle-option${String(vtId) === String(vt.vehicle_type_id) ? " selected" : ""}`}
              onClick={() => setVtId(vt.vehicle_type_id)}>
              <div className="vehicle-name">{vt.type_name}</div>
              <div className="vehicle-rate">${vt.base_fare} + ${vt.rate_per_km}/km</div>
              <div className="vehicle-capacity">👥 {vt.seating_capacity} seats</div>
            </button>
          ))}
        </div>
      </div>
      {fare && (
        <div className="fare-preview">
          <div className="fare-label">Estimated Fare</div>
          <div className="fare-big accent-text">${fare}</div>
          <div className="fare-label" style={{ marginTop: 6 }}>{distance} km · {selectedVt?.type_name}</div>
        </div>
      )}
      <button className="btn btn-primary" onClick={submit} disabled={booking}>
        {booking ? <Spinner /> : <><Icon d={ICONS.car} size={18} />Confirm Booking</>}
      </button>
    </div>
  );
}

// ============================================================
// RIDE CARD
// ============================================================
function RideCard({ ride }) {
  const fare = ride.actual_fare ?? ride.estimated_fare;
  const date = ride.request_time ? new Date(ride.request_time).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }) : "—";
  return (
    <div className="ride-card">
      <div className="ride-header">
        <span className="ride-id">Ride #{ride.ride_id}</span>
        <Badge status={ride.status} />
      </div>
      <div className="route-line">
        <div className="route-point">📍 <span>{ride.pickup_location ?? ride.pickup_location_id ?? "—"}</span></div>
        <div className="route-point">🏁 <span>{ride.dropoff_location ?? ride.dropoff_location_id ?? "—"}</span></div>
      </div>
      <div className="ride-meta">
        <span>📅 {date}</span>
        {ride.distance_km && <span>📏 {ride.distance_km} km</span>}
        {ride.vehicle_type_name && <span>🚗 {ride.vehicle_type_name}</span>}
      </div>
      {fare && <div className="ride-fare accent-text">${Number(fare).toFixed(2)}</div>}
    </div>
  );
}

// ============================================================
// RIDE HISTORY
// ============================================================
function RideHistory({ customer }) {
  const [rides, setRides]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");

  useEffect(() => {
    api.getRides(customer.customer_id)
      .then(data => setRides(data.items ?? data))
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [customer.customer_id]);

  return (
    <div className="page">
      <div style={{ fontSize: 20, fontWeight: 700 }}>Ride History</div>
      {loading ? <Spinner /> : error ? <ErrorBox msg={error} /> : rides.length === 0 ? (
        <div className="empty"><div className="empty-icon">🚕</div><div>No rides yet. Book your first!</div></div>
      ) : rides.map(r => <RideCard key={r.ride_id} ride={r} />)}
    </div>
  );
}

// ============================================================
// PROFILE
// ============================================================
function Profile({ customer, onLogout }) {
  const initials = customer.full_name?.split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  return (
    <div className="page">
      <div style={{ fontSize: 20, fontWeight: 700 }}>Profile</div>
      <div className="card">
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div className="avatar">{initials}</div>
          <div>
            <div style={{ fontSize: 20, fontWeight: 700 }}>{customer.full_name}</div>
            <Badge status={customer.status ?? "ACTIVE"} />
          </div>
        </div>
      </div>
      <div className="card">
        <div className="info-row"><span className="info-label">Customer ID</span><span className="info-value">#{customer.customer_id}</span></div>
        <div className="info-row"><span className="info-label">Phone</span><span className="info-value">{customer.phone}</span></div>
        {customer.email && <div className="info-row"><span className="info-label">Email</span><span className="info-value">{customer.email}</span></div>}
        {customer.address && <div className="info-row"><span className="info-label">Address</span><span className="info-value">{customer.address}</span></div>}
        <div className="info-row">
          <span className="info-label">Member since</span>
          <span className="info-value">{customer.registration_date ? new Date(customer.registration_date).getFullYear() : "—"}</span>
        </div>
      </div>
      <div className="card">
        <div className="stat-row">
          <div><div className="stat-val accent-text">{customer.total_rides ?? 0}</div><div className="stat-label">Rides</div></div>
          <div><div className="stat-val accent-text">${Number(customer.total_spent ?? 0).toFixed(2)}</div><div className="stat-label">Spent</div></div>
        </div>
      </div>
      <button className="btn btn-danger" onClick={onLogout}>
        <Icon d={ICONS.logout} size={18} />Sign Out
      </button>
    </div>
  );
}

// ============================================================
// ROOT APP
// ============================================================
export default function App() {
  const [customer, setCustomer]         = useState(null);
  const [screen, setScreen]             = useState("login"); // login | register
  const [tab, setTab]                   = useState("dashboard");
  const [toast, setToast]               = useState(null);
  const [rides, setRides]               = useState([]);
  const [ridesLoading, setRidesLoading] = useState(false);

  const showToast = useCallback((type, msg) => {
    setToast({ type, msg });
    setTimeout(() => setToast(null), 4000);
  }, []);

  const handleLogin = useCallback((data) => {
    setCustomer(data);
    setTab("dashboard");
    setRidesLoading(true);
    api.getRides(data.customer_id)
      .then(d => setRides(d.items ?? d))
      .catch(() => {})
      .finally(() => setRidesLoading(false));
  }, []);

  const handleRegister = useCallback((data) => {
    // After registration, log them in automatically
    handleLogin(data);
    showToast("success", `Welcome, ${data.full_name}! Your Customer ID is #${data.customer_id}`);
  }, [handleLogin, showToast]);

  const handleLogout = () => { setCustomer(null); setScreen("login"); setTab("dashboard"); setRides([]); };

  const NAV = [
    { id: "dashboard", label: "Home",    icon: ICONS.car },
    { id: "book",      label: "Book",    icon: ICONS.map },
    { id: "history",   label: "History", icon: ICONS.history },
    { id: "profile",   label: "Profile", icon: ICONS.user },
  ];

  return (
    <>
      <style>{styles}</style>
      <Toast toast={toast} />
      <div className="app">
        {!customer ? (
          screen === "register"
            ? <RegisterPage onBack={() => setScreen("login")} onRegister={handleRegister} />
            : <LoginPage onLogin={handleLogin} onRegister={() => setScreen("register")} />
        ) : (
          <>
            <div className="header">
              <span className="header-logo">RapidRide</span>
              <span className="header-welcome">Hi, {customer.full_name?.split(" ")[0]}</span>
            </div>
            {tab === "dashboard" && <Dashboard customer={customer} onBook={() => setTab("book")} recentRides={rides} ridesLoading={ridesLoading} />}
            {tab === "book"      && <BookRide  customer={customer} onToast={showToast} />}
            {tab === "history"   && <RideHistory customer={customer} />}
            {tab === "profile"   && <Profile   customer={customer} onLogout={handleLogout} />}
            <nav className="bottom-nav">
              {NAV.map(n => (
                <button key={n.id} className={`nav-btn${tab === n.id ? " active" : ""}`} onClick={() => setTab(n.id)}>
                  <Icon d={n.icon} size={22} />
                  <span>{n.label}</span>
                </button>
              ))}
            </nav>
          </>
        )}
      </div>
    </>
  );
}
